/*

Template:  Chondo Hotel
Author: Hastech
Version: 1
Design and Developed by: Hastech
NOTE: If you have any note put here. 

*/
(function($) {
    "use strict";
    
    /*-------------------------------------------
    	01. jQuery MeanMenu
    --------------------------------------------- */
    jQuery('nav#dropdown').meanmenu();
    
    /*-------------------------------------------
    	02. wow js active
    --------------------------------------------- */
    new WOW().init();
	
	/*---------
	   3. Preloader
	------------------------*/
		/*$(window).on('load', function() {
			$(".preloader").fadeOut("slow");;
		});*/

	/*---------------------
		4. Mobile menu active
	------------------------*/

	$(window).on('scroll',function() {    
	   var scroll = $(window).scrollTop();
	   if (scroll < 245) {
		$(".sticky-header").removeClass("sticky");
	   }else{
		$(".sticky-header").addClass("sticky");
	   }
	});
	
	
	$('.header-section.static4').parallax("50%", 0.3);
	
    
    $('.date-picker').datepicker({
            startDate: '-3d'
    });


    $('.select-booking').selectpicker({
      style: 'btn-info',
      size: 4
    });
	 
	 
	 
		 
    $(".slider-list").owlCarousel({
      autoPlay: true, 
	  slideSpeed:2000,
	  pagination:false,
	  navigation:true,	  
      items : 1,
	  /* transitionStyle : "fade", */    /* [This code for animation ] */
	  navigationText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
      itemsDesktop : [1199,1],
	  itemsDesktopSmall : [991,1],
	  itemsTablet: [768,1],
	  itemsMobile : [479,1],
    });
    $(".carousel-list").owlCarousel({
      autoPlay: true, 
	  slideSpeed:1500,
	  pagination:true,
	  navigation:false,	  
      items : 3,
	  /* transitionStyle : "fade", */    /* [This code for animation ] */
	  navigationText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
      itemsDesktop : [1199,3],
	  itemsDesktopSmall : [991,2],
	  itemsTablet: [768,2],
	  itemsMobile : [479,1],
    });  
    $(".our-room-list, .our-news-list, .carousel_list").owlCarousel({
      autoPlay: true, 
	  slideSpeed:1500,
	  pagination:true,
	  navigation:false,	  
      items : 1,
	  /* transitionStyle : "fade", */    /* [This code for animation ] */
	  navigationText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
      itemsDesktop : [1199,1],
	  itemsDesktopSmall : [980,1],
	  itemsTablet: [768,1],
	  itemsMobile : [479,1],
    });
    $(".testimonial-list").owlCarousel({
      autoPlay: true, 
	  slideSpeed:1400,
	  pagination:true,
	  navigation:false,	  
      items : 1,
	 /* transitionStyle : "backSlide",
	  navigationText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],*/
      itemsDesktop : [1199,1],
	  itemsDesktopSmall : [980,1],
	  itemsTablet: [768,1],
	  itemsMobile : [479,1],
    });
	
	 $(".testimoniallist").owlCarousel({
      autoPlay: true, 
	  slideSpeed:1400,
	  pagination:true,
	  navigation:false,	  
      items : 1,
	 /* transitionStyle : "backSlide",
	  navigationText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],*/
      itemsDesktop : [1199,1],
	  itemsDesktopSmall : [980,1],
	  itemsTablet: [768,1],
	  itemsMobile : [479,1],
    });
	
	$(".testimonial_list").owlCarousel({
      autoPlay: true, 
	  slideSpeed:1400,
	  pagination:false,
	  navigation:true,	  
      items : 1,
	 /* transitionStyle : "backSlide", */
	  navigationText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"], 
      itemsDesktop : [1199,1],
	  itemsDesktopSmall : [980,1],
	  itemsTablet: [768,1],
	  itemsMobile : [479,1],
    });
	
    $(".team-brand").owlCarousel({
    autoPlay: true, 
	  slideSpeed:2000,
	  pagination:false,
	  navigation:false,	  
      items : 5,
	  transitionStyle : "backSlide",
	  navigationText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
      itemsDesktop : [1199,5],
	  itemsDesktopSmall : [980,4],
	  itemsTablet: [768,3],
	  itemsMobile : [479,2],
    });
     
    $(".team_brand.style2").owlCarousel({
      autoPlay: true, 
	  slideSpeed:2000,
	  pagination:true,
	  navigation:false,	  
      items : 5,
	  transitionStyle : "backSlide",
	  navigationText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
      itemsDesktop : [1199,5],
	  itemsDesktopSmall : [980,4],
	  itemsTablet: [768,3],
	  itemsMobile : [479,2],
    });
   
    
     $('.show_video').magnificPopup({
            disableOn: 0,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 160,
            preloader: true,
            fixedContentPos: false
        });
    
     $('.single-gallery-img a, .single_gallery_inner a, .single-gallery-inner a').magnificPopup({
            type: 'image',
            gallery:{enabled:true},
            zoom: {
                 enabled: true,
                 duration: 300,
            }
    });
   
    $('.counter').counterUp({
        delay: 70,
        time: 5000
    }); 
    
    $.scrollUp({
        scrollText: '<i class="fa fa-angle-up"></i>',
        easingType: 'linear',
        scrollSpeed: 900,
        animation: 'fade'
    });
    
    
    $(window).on('load', function () {
    //Isotope Activated
		if ($.fn.isotope) {

			$(".our_gallery_item").isotope({
					filter: '*',
					layoutMode: 'packery',
					itemSelector: '.single_gallery',
				});

				$('.gallery-menu-filter li').on('click', function () {
					$(".gallery-menu-filter li").removeClass("active");
					$(this).addClass("active");

					var selector = $(this).attr('data-filter');
					$(".our_gallery_item").isotope({
						filter: selector,
						animationOptions: {
							duration: 0,
							easing: 'linear',
							queue: false,
						}
					});
					return false;
				});


			}
	}); 
	 
	 
    $('.tlt').textillate({
        loop: true,
        minDisplayTime: 2500
    });
     
	 
	 
    $(".player").YTPlayer({
        showControls: false
    });
    
    
	/*------------------------------ */

$('#sign_in-bar').on('click', function(){  
		$('.sign_in').removeClass('slideOutUp').addClass('slideInDown');
	});
$('#sign_up-bar').on('click', function(){   
		$('.sign_up').removeClass('slideOutUp').addClass('slideInDown');
	});	 

$('#signin_min-bar').on('click', function(){   
		$('.sign_in').removeClass('slideOutUp').addClass('slideInDown');
	});
$('#signup_min-bar').on('click', function(){   
		$('.sign_up').removeClass('slideOutUp').addClass('slideInDown');
	});

$('.search-open').on('click', function(){
		$('.search-bar').removeClass('slideOutUp').addClass('slideInDown');
	});

	$('.close-search').on('click', function(){
		$('.search-bar').removeClass('slideInDown').addClass('slideOutUp');
        
    });
   
	 
	
	  /*----------------------------*/
   
$( "#availability" ).click(function() {
var citySel =$('#citySel').val();
var stateSel =$('#stateSel').val();
var countySel =$('#countySel').val(); alert(countySel);
 /* $.post("json.html",
    {
        citySel: citySel,
        stateSel: stateSel,
		countySel: countySel  
    },
    function(data, status){
       
	   $('#tableInfo').html(data);
    });*/
});
	
$('.carousel').carousel({
   interval: 3000
})

$(window).load(function() { // makes sure the whole site is loaded
		$("#status").fadeOut(); // will first fade out the loading animation
		$("#preloader").delay(350).fadeOut("slow"); // will fade out the white DIV that covers the website.
	})
    

    
})
(jQuery);




